def Display(no):
    for i in range(0,no):
        print("*",end=" ")

def main():
    no = int(input("Enter Number\n"))
    Display(no)

if __name__ =="__main__":
    main()