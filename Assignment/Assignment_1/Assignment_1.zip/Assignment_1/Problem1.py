# Whrite one Function and that Function Should Display "Hello from Fun" that Function.

def Fun():

    print("Hello From Fun")

def main():
    Fun()

if __name__ == "__main__":
    main()