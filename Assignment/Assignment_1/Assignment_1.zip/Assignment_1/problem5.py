#Display 10 to 1 on Screen

def Display():

    i = 10
    while i>0:
        print(i,end=" ")
        i-=1

def main():
    Display()

if __name__ =="__main__":
    main()