def main():
    str = input("Enter String\n")

    print(len(str))

if __name__ =="__main__":
    main()