
def Addition(Value1,Value2):
    Ans = Value1+Value2
    return Ans

def Substraction(Value1,Value2):
    Ans = Value1-Value2
    return Ans

def Multiplication(Value1,Value2):
    Ans = Value1*Value2
    return Ans

def Division(Value1,Value2):
    Ans = Value1/Value2
    return Ans

